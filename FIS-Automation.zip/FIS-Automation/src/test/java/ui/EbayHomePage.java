package ui;

public class EbayHomePage {
}
